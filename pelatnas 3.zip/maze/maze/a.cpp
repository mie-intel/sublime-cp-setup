#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

int score = 0;
vector <string> res(1000), s(1000);

int n, m;

void cpy(){
	for(int a = 1; a <= n; ++a) res[a] = s[a];
}

int x[] = {-1, 0, 1, 0};
int y[] = {0, -1, 0, 1};
bool possible(int i, int j, int pi, int pj){
	if(i < 1 || i > n || j < 1 || j > m) return 0;
	if(s[i][j] == '.' || s[i][j] == 'X') return 0;
	// cout << "IN " << i << " " << j << '\n';
	for(int a = 0; a < 4; ++a){
		int ti = i + x[a];
		int tj = j + y[a];
		if(ti == pi || tj == pj) continue;
		// cout << "CEK " << ti << " " << tj << '\n';
		if(ti < 1 || ti > n || tj < 1 || tj > m) return 0;
		if(s[ti][tj] == '.') return 0;
	}
	return 1;
}

void dfs(int i, int j, int dep){
	// cout << "VISIT " << i << " " << j << '\n';
	if(dep > score) cpy(), score = dep;
	s[i][j] = '.';
	for(int a = 0; a < 4; ++a){
		if(possible(i + x[a], j + y[a], i, j)) dfs(i + x[a], j + y[a], dep + 1);
	}
	s[i][j] = '#';
}

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	cin >> n >> m;
	for(int a = 1; a <= n; ++a){
		cin >> s[a];
		s[a] = "~" + s[a];
	}

	for(int a = 2; a < n; ++a){
		dfs(a, 1, 1);
	}
	for(int a = 2; a < n; ++a){
		dfs(a, m, 1);
	}

	for(int a = 2; a < m; ++a){
		dfs(1, a, 1);
	}

	for(int a = 2; a < m; ++a){
		dfs(n, a, 1);
	}

	for(int a = 1; a <= n; ++a){
		for(int b = 1; b <= m; ++b){
			cout << res[a][b];
		}
		cout << '\n';
	}

	return 0;
}