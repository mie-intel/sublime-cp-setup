#include "stellaron.h"
#include <bits/stdc++.h>
using namespace std;

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);

  int N, K;
  cin >> N >> K;

  vector<int> A(N + K);
  for (int i = 0; i < N + K; ++i) {
    cin >> A[i];
  }

  vector<int> result = seal_stellaron(N, K, A);

  for (int i = 0; i < (int)result.size(); ++i) {
    cout << result[i] << " \n"[i + 1 == (int)result.size()];
  }

  return 0;
}