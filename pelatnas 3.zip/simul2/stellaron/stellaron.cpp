#include "stellaron.h"



#pragma GCC optimize("Ofast")

#pragma GCC target("avx,avx2,fma,lzcnt,popcnt")



#include <bits/stdc++.h>

using namespace std;



typedef long long ll;

#define fi first

#define se second



vector<int> seal_stellaron(int n, int k, vector<int> A) {

    int tot = n + k;

    for(short bit = (1 << n) - 1; bit < (1 << tot); ++bit){

        if(__builtin_popcount(bit) != n) continue;

        vector <int> used;

        for(short a = 0; a < tot; ++a){

            if((bit & (1 << a))) used.push_back(A[a]);

        }

        int diff = used.back() + used[0];

        bool same = 1;

        for(int a = 0; a < used.size() / 2; ++a){

            if(used[a] + used[used.size() - 1 - a] != diff){

                same = 0;

                break;

            }

        }

        if(same) return used;

    }

}