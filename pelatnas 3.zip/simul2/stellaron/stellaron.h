#ifndef __STELLARON_H__
#define __STELLARON_H__

#include <vector>
using namespace std;

vector<int> seal_stellaron(int N, int K, vector<int> A);

#endif
