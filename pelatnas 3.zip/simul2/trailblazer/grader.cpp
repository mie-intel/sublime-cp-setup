#include "trailblazer.h"
#include <iostream>

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);

  int t;
  cin >> t;

  for (int tc = 0; tc < t; ++tc) {
    int N;
    cin >> N;

    vector<int> A(N);
    for (int i = 0; i < N; ++i) {
      cin >> A[i];
    }

    cout << split_trash(N, A) << "\n";
  }

  return 0;
}