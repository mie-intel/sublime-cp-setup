#ifndef __TRAILBLAZER_H__
#define __TRAILBLAZER_H__

#include <vector>
using namespace std;

int split_trash(int N, vector<int> A);

#endif
