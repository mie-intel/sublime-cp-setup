#include "trailblazer.h"

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

int split_trash(int N, vector<int> A) {
    vector <pair <int, int>> dp = {{-1, -1}};
    for(int a = 0; a < A.size(); ++a){
        int i = lower_bound(dp.begin(), dp.end(), make_pair(A[a], -1)) - dp.begin();
        if(i == dp.size()) dp.emplace_back(A[a], a);
        else if(dp[i].fi > A[a]) dp[i] = make_pair(A[a], a);
    }
    int sz = dp.size() - 1;
    return min(sz + 1, N);
}

