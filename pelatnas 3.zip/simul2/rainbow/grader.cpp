#include "rainbow.h"
#include <bits/stdc++.h>
using namespace std;

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);

  int N, M, Q;
  cin >> N >> M >> Q;

  vector<int> A(M);
  for (int i = 0; i < M; ++i) {
    cin >> A[i];
  }

  vector<int> u(N - 1), v(N - 1);
  for (int i = 0; i < N - 1; ++i) {
    cin >> u[i];
  }
  for (int i = 0; i < N - 1; ++i) {
    cin >> v[i];
  }

  init(N, M, A, u, v);

  vector<int> ans;
  for (int i = 0; i < Q; ++i) {
    int op;
    cin >> op;

    if (op == 1) {
      int l, r, p;
      cin >> l >> r >> p;
      travel(l, r, p);
    } else if (op == 2) {
      int p, d;
      cin >> p >> d;
      festival(p, d);
    } else if (op == 3) {
      int b;
      cin >> b;
      ans.push_back(hope(b));
    } else {
      return 1;
    }
  }

  for (int i = 0; i < ans.size(); ++i) {
    cout << ans[i] << " \n"[i + 1 == (int)ans.size()];
  }

  return 0;
}
