#ifndef __RAINBOW_H__
#define __RAINBOW_H__

#include <vector>
using namespace std;

void init(int N, int M, vector<int> A, vector<int> u, vector<int> v);

void travel(int l, int r, int p);

void festival(int p, int d);

long long hope(int b);

#endif
