/*
	Gatau males pengen beli truk
*/

#include "rainbow.h"

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

const int maxn = 2e5 + 8;
ll pos[maxn], dep[maxn], st[maxn];
vector <vector <int>> v(maxn);
vector <int> euler;
int tt = 0;
ll M = 0;

void dfs(int a, int pr, int dp){
	dep[a] = dp;
	st[a] = tt++;
	euler.push_back(a);
	for(auto p : v[a]){
		if(p == pr) continue;
		dfs(p, a, dp + 1);
		euler.push_back(a);
		tt++;
	}
}

const int maxk = 25;
int sparse[maxn + maxn][maxk];
int lgm[maxn + maxn];

int mini(int a, int b){
	return dep[a] < dep[b] ? a : b;
}

void build_sparse(){
	assert(euler.size() < maxn + maxn);
	for(int a = 2; a < maxn + maxn; ++a) lgm[a] = lgm[a / 2] + 1;
	for(int a = 0; a < euler.size(); ++a) sparse[a][0] = euler[a];
	for(int b = 1; b < maxk; ++b){
		for(int a = 0; a + (1 << b) < euler.size(); ++a){
			sparse[a][b] = mini(sparse[a][b - 1], sparse[a + (1 << (b - 1))][b - 1]);
		}
	}
}

int lca(int a, int b){
	int pa = min(st[a], st[b]);
	int pb = max(st[a], st[b]);
	int lg = lgm[pb - pa + 1];
	// assert(pb >= pa);
	return mini(sparse[pa][lg], sparse[pb - (1 << lg) + 1][lg]);
}

ll dist(int a, int p){
	// assert(a != 0 && p != 0);
	// assert(dep[a] + dep[p] - 2 * dep[lca(a, p)] >= 0);
	return dep[a] + dep[p] - dep[lca(a, p)] - dep[lca(a, p)];
}

ll seg[4 * maxn], lz[4 * maxn], mx[4 * maxn], mn[4 * maxn];

void merge(int v){
	seg[v] = seg[2 * v] + seg[2 * v + 1];
	mx[v] = max(mx[2 * v], mx[2 * v + 1]);
	mn[v] = min(mn[2 * v], mn[2 * v + 1]);
	// assert(mx[v] >= mn[v]);
}

void prop(int l, int r, int v){
	assert(r >= l);
	// assert(lz[v] <= 0);
	// assert(mx[v] == mn[v]);
	seg[v] += ((ll)lz[v]) * (r - l + 1ll);
	if(l < r){
		mx[2 * v] = mx[2 * v + 1] = mn[2 * v] = mn[2 * v + 1] = mx[v];
		lz[2 * v] += lz[v];
		lz[2 * v + 1] += lz[v];
	}
	lz[v] = 0;
}

void build(int l, int r, int v){
	if(l == r){
		seg[v] = 0;
		lz[v] = 0;
		assert(pos[l] != 0);
		mx[v] = pos[l];
		mn[v] = pos[l];
	}
	else{
		lz[v] = 0;
		int mid = (l + r)/2;
		build(l, mid, 2 * v);
		build(mid + 1, r, 2 * v + 1);
		merge(v);
	}
}

void update(int l, int r, int v, int lq, int rq, int go){
	assert(lq <= rq);
	if(lz[v] != 0) prop(l, r, v);
	if(l > rq || r < lq) return;
	if(lq <= l && r <= rq && mx[v] == mn[v]){
		lz[v] += dist(mx[v], go);
		mx[v] = go;
		mn[v] = go;
		prop(l, r, v);
		return;
	}
	int mid = (l + r)/2;
	update(l, mid, 2 * v, lq, rq, go);
	update(mid + 1, r, 2 * v + 1, lq, rq, go);
	merge(v);
}

ll query(int l, int r, int v, int posi){
	assert(l <= posi && posi <= r);
	if(lz[v] != 0) prop(l, r, v);
	if(l == r){
		// assert(l == posi);
		// assert(mx[v] == mn[v]);
		// assert(lz[v] == 0);
		return seg[v];
	}
	int mid = (l + r)/2;
	if(posi <= mid) return query(l, mid, 2 * v, posi);
	else return query(mid + 1, r, 2 * v + 1, posi);
}

void init(int N, int _M, vector<int> A, vector<int> U, vector<int> V) {
	M = _M;
	for(int a = 0; a < M; ++a){
		pos[a + 1] = A[a];
	}
	for(int a = 0; a < N - 1; ++a){
		v[U[a]].push_back(V[a]);
		v[V[a]].push_back(U[a]);
	}
	dfs(1, -1, 0);
	build_sparse();
	build(1, M, 1);
	assert(M != 0);
}

void travel(int l, int r, int p) {
	if(l > r) swap(l, r);
	// untuk segmen yang udah pernah ngelewatin kota yang sama, tinggal lazy_prop sum biasa
	// kalo engga, samain dulu
	assert(M != 0);
	update(1, M, 1, l, r, p);
}

void festival(int p, int d) {
	assert(1 == 2);
}

long long hope(int b) {
	// // assert(res <= 0);
	return -query(1, M, 1, b);
}

/*
5
4
4
2 3 4 5
1 2
1 3
1 4
1 5
1 1 4 1
1 1 4 2
3 1
3 3

*/
