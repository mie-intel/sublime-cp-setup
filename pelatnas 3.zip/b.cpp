#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

const int maxn = 1e6 + 1;
vector <int> v(maxn, -1);
const ll lg = 64;
ll naik[maxn][lg];
ll arr[maxn];

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	ll n, k, ke;
	cin >> n >> k >> ke;

	auto jar = [&](int i, int j) -> ll{
		return abs(arr[i] - arr[j]);
	};

	auto par = [&](int a, int lq, int rq) -> pair <ll, ll>{
		ll dl = jar(a, lq);
		ll dr = jar(a, rq);
		if(dl >= dr){
			return make_pair(dl, lq);
		}
		else
			return make_pair(dr, rq);
	};

	for(int a = 1; a <= n; ++a){
		cin >> arr[a];
	}

	for(ll a = 1; a <= n; ++a){
		pair <ll, ll> res = make_pair(LLONG_MAX, LLONG_MAX);
		if(a + k <= n && ans > jar(a, a + k)){
			ans = jar(a, a + k);
			node = a + k;
		}
		if(a - k >= 1 && ans >= jar(a, a - k)){
			ans = jar(a, a - k);
			node = a - k;
		}
		ll dis = min(k - 1, n - a);
		ll ambil = a - 1;
		int r = dis, l = k - (a - 1), m;
		// cout << "RANGE " << l << " " << r << '\n';
		bool fi = 1;
		while(l <= r){
			m = (l + r)/2;
			int rq = a + m;
			int lq = a - (k - m);
			// cout << "BINSER " << a << " " << lq << " " << rq << '\n';
			int dr = jar(a, rq);	
			int dl = jar(a, lq);

			if(dl >= dr){
				if(ans > dl){
					ans = dl;
					node = lq;
				}
			}
			else{
				if(ans > dr){
					ans = dr;
					node = rq;
				}
			}

			if(dl <= dr){
				// gerak ke kiri
				r = m - 1;
			}
			else{
				// gerak ke kanan
				l = m + 1;
			}
		}
		v[a] = node;
		// if(v[a] == INT_MAX){
		// 	cout << "ANJAY";
		// 	return 0;
		// }
		// assert(v[a] != INT_MAX);
	}

	for(ll a = 0; a < lg; ++a){
		for(ll b = 1; b <= n; ++b){
			if(a == 0) naik[b][a] = v[b];
			else naik[b][a] = naik[naik[b][a - 1]][a - 1];
		}
	}

	// cout << "PASANGAN\n";
	// for(int a = 1; a <= n; ++a) cout << v[a] << " \n"[a == n];

	for(int a = 1; a <= n; ++a){
		ll go = ke;
		int pt = a;
		for(ll b = lg - 1; b >= 0; --b){
			if(go & (1ll << b)) pt = naik[pt][b];
		}
		cout << pt << " ";
	}
	cout << '\n';

	return 0;
}

/*
k = 3

_ _ _ _ _ _ _ _ _ _ 
  u
  i i
*/