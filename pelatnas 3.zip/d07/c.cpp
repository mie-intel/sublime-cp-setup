#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

const int maxn = 2e5 + 1;
vector <vector <int>> v(maxn);
vector <vector <int>> scc(maxn);
set <int> st[maxn];
int sol[maxn]; // definisikan node bawah yang harus dikunjungin oleh suatu node
int hv[maxn], sz[maxn];

int par[maxn], parl[maxn];

int fen[maxn];

void upd(int pos, int val){
	while(pos < maxn){
		fen[pos] += val;
		pos += (pos & -pos);
	}
}

ll query(int pos){
	ll res = 0;
	while(pos >= 1){
		res += fen[pos];
		pos -= (pos & -pos);
	}
	return res;
}

int find(int a){
	return par[a] == a ? a : par[a] = find(par[a]);
}

bool same(int a, int b){
	return find(a) == find(b);
}

void join(int a, int b){
	int pa = find(a);
	int pb = find(b);
	if(pa == pb) return;
	for(auto p : st[pb]){
		st[pa].insert(p);
	}
	st[pb].clear();
	par[pb] = pa;
}

void dfs(int a, int pr){
	parl[a] = pr;
	for(auto p : v[a]){
		if(p == pr) continue;
		if(p < a) join(a, p);
		dfs(p, a);
	}
}

void decompose(int a, int pr){
	for(auto p : v[a]){
		if(!same(p, a)){
			scc[a].push_back(p);
		}
	}
}

vector <int> euler;
int str[maxn], en[maxn];
int tt = 0;

void comp(int a){
	euler.push_back(a);
	str[a] = en[a] = tt++;
	sz[a] = 1;
	int mx = -1;
	hv[a] = -1;
	for(auto p : scc[a]){
		comp(p);
		par[p] = a;
		sz[a] += sz[p];
		if(sz[p] > mx){
			mx = sz[p];
			hv[a] = p;
		}
		euler.push_back(a);
		en[a] = tt++;
	}
}

void dsu(int a, int pr, int bg){
	for(auto p : scc[a]){
		if(p == pr || p == hv[a]) continue;
		dsu(p, a, 0);
	}
	if(hv[a] != -1){
		dsu(hv[a], a, 1);
	}

	for(int i = str[a] + 1; i < en[a]; ++i){
		if(euler[i] == hv[a]){
			i = en[euler[i]];
			continue;
		}
		if(i == en[euler[i]]) continue;
		for(auto p : st[euler[i]]){
			upd(p, 1);
			cout << "A " << euler[i] << " " << p << '\n';
		}
	}

	sol[a] = query(parl[a]);

	if(!bg){
		for(int i = str[a] + 1; i < en[a]; ++i){
			if(i == en[euler[i]]) continue;
			for(auto p : st[euler[i]]){
				upd(p, -1);
			}
		}
	}
}

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int n;
	cin >> n;
	for(int a = 1; a < n; ++a){
		int i, j;
		cin >> i >> j;
		v[i].push_back(j);
		v[j].push_back(i);
	}

	for(int a = 1; a <= n; ++a) par[a] = a, st[a].insert(a);
	dfs(1, -1);
	decompose(1, -1);
	comp(1);
	dsu(1, -1, 1);

	for(int a = 2; a <= n; ++a) cout << sol[find(a)] << " \n"[a == n];
	for(int a = 2; a <= n; ++a) cout << parl[a] << " \n"[a == n];

	return 0;
}