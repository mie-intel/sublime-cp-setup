#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

vector <int> used;
vector <int> un;
vector <pair <int, int>> pasang;

const ll mod = 1e9 + 7;
ll ans = 0;
int n, k;

const int maxn = 11;
int par[maxn];

int find(int a){
	return par[a] == a ? a : par[a] = find(par[a]);
}

bool same(int a, int b){
	return find(a) == find(b);
}

void join(int a, int b){
	par[find(a)] = find(b);
}

bool inter(pair <int, int> a, pair <int, int> b){
	if(a.fi <= b.fi && b.fi <= a.se && b.fi <= a.se && a.se <= b.se) return 1;
	if(b.fi <= a.fi && a.fi <= b.se && a.fi <= b.se && b.se <= a.se) return 1;
	return 0;
}
void calc(){
	for(int a = 1; a < maxn; ++a) par[a] = a;
	for(int a = 0; a < pasang.size(); ++a){
		for(int b = a + 1; b < pasang.size(); ++b){
			if(inter(pasang[a], pasang[b])) join(pasang[a].fi, pasang[b].fi);
		}
	}
	set <int> st;
	for(int a = 0; a < pasang.size(); ++a){
		st.insert(find(pasang[a].fi));
	}
	ans += st.size();
	ans %= mod;
}

void brute(int i){
	if(pasang.size() == n){
		calc();
		// for(int a = 0; a < pasang.size(); ++a){
		// 	cout << pasang[a].fi << " " << pasang[a].se << '\n';
		// }
		// cout << ans << '\n';
		return;
	}

	for(int a = i; a < un.size(); ++a){
		if(used[un[a]]) continue;
		for(int b = a + 1; b < un.size(); ++b){
			if(used[un[b]]) continue;
			pasang.emplace_back(un[a], un[b]);
			used[un[a]] = used[un[b]] = 1;
			brute(a + 1);
			pasang.pop_back();
			used[un[a]] = used[un[b]] = 0;
		}
	}
}

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	cin >> n >> k;
	used.resize(2 * n + 2, 0);
	for(int a = 1; a <= k; ++a){
		int i, j;
		cin >> i >> j;
		if(i > j) swap(i, j);
		pasang.emplace_back(i, j);
		used[i] = used[j] = 1;
	}

	for(int a = 1; a <= 2 * n; ++a){
		if(!used[a]){
			un.push_back(a);
		}
	}

	brute(0);

	cout << ans << '\n';

	return 0;
}	