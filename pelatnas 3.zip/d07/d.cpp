#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

void solveM(int n, int m, int i, int j, int k){
	string s[2 * n + 1];
	for(int a = 1; a <= 2 * n; ++a){
		s[a] = "~";
		for(int b = 1; b <= 2 * m; ++b) s[a] += '.';
	}

	int it = i;
	int pos_i = -1, pos_j = -1;
	int ci = 0, cj = 0, ck = 0;

	// itemin
	for(int a = 1; a <= 2 * n && it; a += 2){
		for(int b = 1; b <= 2 * m && it; b += 2){
			s[a][b] = s[a + 1][b] = s[a][b + 1] = s[a + 1][b + 1] = '#';
			it--;
			if(it == 0) pos_i = a, pos_j = b;
			ci++;
		}
	}
	if(pos_i == -1 && pos_j == -1){
		pos_i = pos_j = 1;
	}
	else{
		pos_j += 2;
		if(pos_j > 2 * m){
			pos_i += 2;
			pos_j = 1;
		}
	}

	it = k;
	while(it){
		// isi di posisi pos_i
		int cc = 1;
		for(int rep = 0; rep <= 1 && it; ++rep){
			for(int a = pos_j; a <= 2 * m && it; a += 2){
				if(cc){
					/*
						x/
						/.
					*/
					if(rep == 0){
						s[pos_i][a] = '#';
						s[pos_i][a + 1] = '/';
						s[pos_i + 1][a] = '/';
						s[pos_i + 1][a + 1] = '.';
					}

					else{
						/*
							\.
							x\
						*/
						s[pos_i][a] = '\\';
						s[pos_i][a + 1] = '.';
						s[pos_i + 1][a] = '#';
						s[pos_i + 1][a + 1] = '\\';						
					}
				}
				else{
					if(rep == 0){
						/*
							\x
							.\
						*/
						s[pos_i][a] = '\\';
						s[pos_i][a + 1] = '#';
						s[pos_i + 1][a] = '.';
						s[pos_i + 1][a + 1] = '\\';
					}
					else{
						/*
							./
							/x
						*/
						s[pos_i][a] = '.';
						s[pos_i][a + 1] = '/';
						s[pos_i + 1][a] = '/';
						s[pos_i + 1][a + 1] = '#';
					}
				}
				cc = 1 - cc;
				it--;
				ck++;
			}
			pos_i += 2;
			cc = 1;
			for(int a = pos_j - 2; a >= 0 && it; a -= 2){
				if(cc){
					if(rep == 0){
						/*
							x/
							/.
						*/
						s[pos_i][a] = '#';
						s[pos_i][a + 1] = '/';
						s[pos_i + 1][a] = '/';
						s[pos_i + 1][a + 1] = '.';
					}
					else{
						/*
							\.
							x\
						*/
						s[pos_i][a] = '\\';
						s[pos_i][a + 1] = '.';
						s[pos_i + 1][a] = '#';
						s[pos_i + 1][a + 1] = '\\';							
					}
				}
				else{
					if(rep == 0){
						/*
							\x
							.\
						*/
						s[pos_i][a] = '\\';
						s[pos_i][a + 1] = '#';
						s[pos_i + 1][a] = '.';
						s[pos_i + 1][a + 1] = '\\';
					}
					else{
						/*
							x/
							/.
						*/
						s[pos_i][a] = '#';
						s[pos_i][a + 1] = '/';
						s[pos_i + 1][a] = '/';
						s[pos_i + 1][a + 1] = '.';							
					}
				}
				cc = 1 - cc;
				it--;
				ck++;
			}
		}
	}

	cj = n * m - ci - ck;

	for(int a = 1; a <= 2 * n; ++a){
		for(int b = 1; b <= 2 * m; ++b) cout << s[a][b];
		cout << '\n';
	}
}

void solveMM(int n, int m, int i, int j, int k){
	string s[2 * n + 1];
	for(int a = 1; a <= 2 * n; ++a){
		s[a] = "~";
		for(int b = 1; b <= 2 * m; ++b) s[a] += '.';
	}

	int it = i;
	int pos_i = -1, pos_j = -1;
	int ci = 0, cj = 0, ck = 0;

	// itemin
	for(int a = 1; a <= 2 * n && it; a += 2){
		for(int b = 1; b <= 2 * m && it; b += 2){
			s[a][b] = s[a + 1][b] = s[a][b + 1] = s[a + 1][b + 1] = '#';
			it--;
			if(it == 0) pos_i = a, pos_j = b;
			ci++;
		}
	}
	if(pos_i == -1 && pos_j == -1){
		pos_i = pos_j = 1;
	}
	else{
		pos_j += 2;
		if(pos_j > 2 * m){
			pos_i += 2;
			pos_j = 1;
		}
	}

	it = k;
	while(it){
		// isi di posisi pos_i
		int cc = 1;
		for(int rep = 0; rep <= 0 && it; ++rep){
			for(int a = pos_j; a <= 2 * m && it; a += 2){
				if(cc){
					/*
						x/
						/.
					*/
					if(rep == 0){
						s[pos_i][a] = '#';
						s[pos_i][a + 1] = '/';
						s[pos_i + 1][a] = '/';
						s[pos_i + 1][a + 1] = '.';
					}

					else{
						/*
							\.
							x\
						*/
						s[pos_i][a] = '\\';
						s[pos_i][a + 1] = '.';
						s[pos_i + 1][a] = '#';
						s[pos_i + 1][a + 1] = '\\';						
					}
				}
				else{
					if(rep == 0){
						/*
							\x
							.\
						*/
						s[pos_i][a] = '\\';
						s[pos_i][a + 1] = '#';
						s[pos_i + 1][a] = '.';
						s[pos_i + 1][a + 1] = '\\';
					}
					else{
						/*
							./
							/x
						*/
						s[pos_i][a] = '.';
						s[pos_i][a + 1] = '/';
						s[pos_i + 1][a] = '/';
						s[pos_i + 1][a + 1] = '#';
					}
				}
				cc = 1 - cc;
				it--;
				ck++;
			}
			pos_i += 2;
		}
		break;
	}

	// cout << "SISA " << it << '\n';
	while(it){
		int last_i = -1, last_j = -1;
		bool valid = 0;
		for(int a = pos_i; a + 3 <= 2 * n && it >= 4; a += 4){
			for(int b = pos_j + 2; b + 3 <= 2 * m && it >= 4; b += 4){
				s[a][b + 2] = '\\';
				s[a][b + 3] = '.';
				s[a + 1][b + 2] = '#';
				s[a + 1][b + 3] = '\\';
				s[a + 2][b + 2] = '#';
				s[a + 2][b + 3] = '/';
				s[a + 3][b + 2] = '/';
				s[a + 3][b + 3] = '.';
				s[a][b + 0] = '.';
				s[a][b + 1] = '/';
				s[a + 1][b + 0] = '/';
				s[a + 1][b + 1] = '#';
				s[a + 2][b + 0] = '\\';
				s[a + 2][b + 1] = '#';
				s[a + 3][b + 1] = '.';
				s[a + 3][b + 1] = '\\';	
				it -= 4;		
				last_i = a + 3;
				last_j = b + 3;
				valid = 1;
			}
		}
		if(!valid) break;
		pos_i = last_i + 1;
	}

	// cout << "IT IT " << it << '\n';
	if(it >= 2){
		for(int a = 1; a + 3 <= 2 * n && it >= 2; ++a){
			if(s[a][1] == '.' && s[a][2] == '.' && s[a + 1][1] == '.' && s[a + 1][2] == '.'
				&& s[a + 2][1] == '.' && s[a + 2][2] == '.' && s[a + 3][1] == '.' && s[a + 3][2] == '.'){
					s[a][1] = '\\';
					s[a][2] = '.';
					s[a + 1][1] = '#';
					s[a + 1][2] = '\\';
					s[a + 2][1] = '#';
					s[a + 2][2] = '/';
					s[a + 3][1] = '/';
					s[a + 3][2] = '.';	
					it -= 2;	
			}
		}
	}

	if(it >= 2){
		for(int a = 1; a + 3 <= 2 * n && it >= 2; ++a){
			if(s[a][2 * m - 1] == '.' && s[a][2 * m] == '.' && s[a + 1][2 * m - 1] == '.' && s[a + 1][2 * m] == '.'
				&& s[a + 2][2 * m - 1] == '.' && s[a + 2][2 * m] == '.' && s[a + 3][2 * m - 1] == '.' && s[a + 3][2 * m] == '.'){
					s[a][2 * m - 1] = '.';
					s[a][2 * m] = '/';
					s[a + 1][2 * m - 1] = '/';
					s[a + 1][2 * m] = '#';
					s[a + 2][2 * m - 1] = '\\';
					s[a + 2][2 * m] = '#';
					s[a + 3][2 * m - 1] = '.';
					s[a + 3][2 * m] = '\\';	
					it -= 2;	
			}
		}
	}

	while(it >= 2){
		for(int a = 1; a + 3 <= 2 * m && it >= 2; ++a){
			if(s[2 * n - 1].substr(a, 4) == "...." && s[2 * n].substr(a, 4) == "...."){
				/*
					./\.
					/xx\
				*/
				s[2 * n - 1][a] = '.';
				s[2 * n - 1][a + 1] = '/';
				s[2 * n - 1][a + 2] = '\\';
				s[2 * n - 1][a + 3] = '.';
				s[2 * n][a] = '/';
				s[2 * n][a + 1] = '#';
				s[2 * n][a + 2] = '#';
				s[2 * n][a + 3] = '\\';
				it -= 2;
			}
		}
	}

	// check ujung kiri
	if(it && s[2 * n - 1][1] == '.' &&
		s[2 * n - 1][2] == '.' &&
		s[2 * n][1] == '.' &&
		s[2 * n][2] == '.'){
			s[2 * n - 1][1] = '\\';
			s[2 * n][1] = '#';
			s[2 * n][2] = '\\';
		it--;
	}
	
	if(it){
		if(s[2 * n - 1][2 * m - 1] == '.' &&
			s[2 * n - 1][2 * m] == '.' &&
			s[2 * n][2 * m - 1] == '.' &&
			s[2 * n][2 * m] == '.'){
				s[2 * n - 1][2 * m] = '/';
				s[2 * n][2 * m] = '#';
				s[2 * n][2 * m - 1] = '/';
			it--;
		}			
	}

	if(it){
		cout << "BENTO\n";
		return;
	}
	for(int a = 1; a <= 2 * n; ++a){
		for(int b = 1; b <= 2 * m; ++b) cout << s[a][b];
		cout << '\n';
	}
}

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int n, m;
	cin >> n >> m;
	int i, j, k, ci = 0, cj = 0, ck = 0;
	cin >> i >> j >> k;
	if(k == 0 && i > 0 && j > 0){
		cout << "BENTO\n";
		return 0;
	}

	if(i % m == 0 && j % m == 0 && k % m == 0){
		solveM(n, m, i, j, k);
		return 0;
	}
	if(k == m){
		solveM(n, m, i, j, k);
		return 0;
	}
	solveMM(n, m, i, j, k);
	return 0;

	cout << "BENTO" << '\n';
	return 0;
}