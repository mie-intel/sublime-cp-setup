// siapa gagal ac angkat tangan?

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

bool debug = 0;

void test_1(int n, int p, int q){
	// cout << "TARGET " << n * (p + q) / (p + 2 * max(p, q)) + 3 * max(p, q) << '\n';
	int tt = n / 2 + 1;
	cout << tt << '\n';
	for(int a = 1; a <= tt; ++a) cout << n / 2 + 1 << " ";
	cout << '\n';
}	

void test_2(int n, int p, int q){
	// cout << "TARGET " << n * (p + q) / (p + 2 * max(p, q)) + 3 * max(p, q) << '\n';
	vector <int> res;
	for(int a = 1; a <= n; ++a) if(a % 2 == 1) res.push_back(a);
	if(n % 2 == 0) res.push_back(n);
	cout << res.size() << '\n';
	for(auto p : res) cout << p << " ";
	cout << '\n';
}

void test_3(int n){
	cout << n - 1 << '\n';
	for(int a = 2; a <= n; ++a){
		if(a % 2 == 0 && a != n) cout << 1;
		else cout << n;
		cout << " ";
	}
	cout << '\n';
}

void test_4(int n, int p, int q){
	// cout << "TARGET " << n * (p + q) / (p + 2 * max(p, q)) + 3 * max(p, q) << '\n';
	// idenya, geser terus sampe kanan, njuk ke kiri
	vector <int> res;
	int l = 1;
	bool first = 1;
	int r = n;
	while(l <= r){
		for(int a = 1; a <= p && l <= r; ++a){
			res.push_back(l);
			if(l == r || l == n){
				l = r + 1;
				break;
			}
			r = min(r + 1, n);
			l = min(l + 2, r);
		}
		// q
		int m = max(r - q, (l + r)/2);
		for(int a = 1; a <= q && l <= r; ++a){
			res.push_back(m);
			if(r == m && l == m){
				l++;
				break;
			}
			if(r > m){
				r--;
			}
			if(l < m){
				l++;
			}
		}
	}
	if(l == r) res.push_back(l);
	cout << res.size() << '\n';
	for(auto p : res) cout << p << " ";
	cout << '\n';
}

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int n, p, q;
	cin >> n >> p >> q;
	if(debug){
		cout << n << " " << p << " " << q << '\n';
	}
	test_4(n, p, q);

	return 0;
}