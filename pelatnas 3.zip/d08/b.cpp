#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int n, q;
	cin >> n >> q;
	string s;
	cin >> s;
	int j = 0, l = 0;
	vector <int> res;
	stack <pair <char, int>> st;
	for(int a = 0; a < s.length(); ++a){
		res.push_back(0);
		if(s[a] == 'J'){
			if(st.empty()) st.emplace(s[a], a);
			else{
				if(st.top().fi == 'J'){
					res[st.top().se] = 3;
					st.pop();
					res[a] = 1;
				}
				else{
					st.emplace(s[a], a);
				}
			}
		}
		else if(s[a] == 'L'){
			if(st.empty()) st.emplace(s[a], a);
			else{
				if(st.top().fi == 'L'){
					res[st.top().se] = 1;
					st.pop();
					res[a] = 3;
				}
				else
					st.emplace(s[a], a);
			}
		}
	}

	if(st.empty()){
		cout << "YES\n";
		for(auto p : res) cout << p << " ";
		cout << '\n';
	}
	else{
		cout << "NO\n";
	}

	return 0;
}