#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int n, p, q;
	cin >> n >> p >> q;
	int m;
	cin >> m;
	vector <int> v(m);
	for(int a = 0; a < m; ++a) cin >> v[a];
	// simulate
	q += p;
	bool res = 1;
	vector <pair <int, int>> salah;
	for(int a = 1; a <= n; ++a){
		// simulate
		int it = 1;
		bool ada = 0;
		int pt = a;
		for(int b = 0; b < m; ++b){
			if(pt == v[b]){
				cout << "A " << a << " AC\n";
				ada = 1;
				break;
			}
			if(it <= p){
				if(pt > v[b]){
					pt = min(pt + 1, n);
				}
				else{
					pt = max(pt - 1, 1);
				}
			}
			else{
				if(pt > v[b]) pt--;
				else pt++;
			}
			it++;
			if(it > q) it = 1;
		}
		if(!ada){
			cout << "WA in " << a << " FOUND " << pt << '\n';
			res = 0;
			salah.emplace_back(a, pt);
		}
	}

	if(!salah.empty()) for(auto [p, q] : salah) cout << "{" << p << " " << q << "}\n";
	int t = n * (p + q) / (p + 2 * max(p, q)) + 3 * max(p, q);
	cout << "TARGET T: " << t << " " << m << '\n';
	if(m <= t && res) cout << "AC\n";
	else{
		cout << "WA\n";
	}

	cout << "REMINDER! " << " n = " << n << " p = " << p << " q = " << q - p << '\n';


	return 0;
}