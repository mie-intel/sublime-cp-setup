#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int n, p, q;
	cin >> n >> p >> q;
	int m;
	cin >> m;
	int t = n * (p + q) / (p + 2 * max(p, q)) + 3 * max(p, q);
	cout << "TARGET T: " << t << " " << m << '\n';
	if(m <= t) cout << "AC\n";
	else cout << "WA\n";

	return 0;
}