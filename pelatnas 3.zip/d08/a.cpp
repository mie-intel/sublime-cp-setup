#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

const int maxn = 2e5 + 1;
ll h[maxn];
vector <vector <pair <int, int>>> v(maxn);
ll ans = 0, sum = 0, tmp = 0;

bitset <maxn> ori;
void dfs(int a, int pr){
	sum += h[a];
	for(auto [p, id] : v[a]){
		if(p == pr) continue;
		if(p > a && ori[id] == 0) continue;
		if(p < a && ori[id] == 1) continue;
		dfs(p, a);
	}
}

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int n;
	cin >> n;
	for(int a = 1; a <= n; ++a){
		cin >> h[a];
	}
	for(int a = 2; a <= n; ++a){
		int p;
		cin >> p;
		v[a].emplace_back(p, a - 2);
		v[p].emplace_back(a, a - 2);
	}

	// brute force
	int m = (n - 1);
	for(int a = 0; a < (1 << m); ++a){
		ori = a;
		tmp = 0;
		for(int a = 1; a <= n; ++a){
			sum = 0;
			dfs(a, -1);
			tmp += h[a] * (sum - 1);
		}
		ans = max(ans, tmp);
	}

	cout << ans << '\n';

	return 0;
}