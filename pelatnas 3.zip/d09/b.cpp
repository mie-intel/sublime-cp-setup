#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());

const int maxn = 3e5 + 2;
int SQRT = sqrt(maxn);

bool cmp(pair <pair <int, int>, pair <int, int>> a, pair <pair <int, int>, pair <int, int>> b){
	if(a.fi.fi / SQRT == b.fi.fi / SQRT) return a.fi.se < b.fi.se;
	else return a.fi.fi / SQRT < b.fi.fi / SQRT;
}

int freq[maxn], sol[maxn], arr[maxn];
vector <pair <pair <int, int>, pair <int, int>>> qu;

int lq = 1, rq = 0;
int query(int l, int r, int k){
	while(rq < r) freq[arr[++rq]]++;
	while(lq > l) freq[arr[--lq]]++;
	while(rq > r) freq[arr[rq--]]--;
	while(lq < l) freq[arr[lq++]]--;
	int cnt = 110;
	int res = INT_MAX;
	int len = r - l + 1;
	while(cnt--){
		int pos = (rng() % len) + l;
		if(freq[arr[pos]] > len / k) res = min(res, arr[pos]);
	}
	if(res == INT_MAX) res = -1;
	return res;
}

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int n, q;
	cin >> n >> q;
	SQRT = ceil(sqrt(n));
	for(int a = 1; a <= n; ++a){
		cin >> arr[a];
	}

	for(int a = 0; a < q; ++a){
		int i, j, k;
		cin >> i >> j >> k;
		qu.push_back(make_pair(make_pair(i, j), make_pair(k, a)));
	}
	sort(qu.begin(), qu.end(), cmp);
	for(int a = 0; a < q; ++a){
		sol[qu[a].se.se] = query(qu[a].fi.fi, qu[a].fi.se, qu[a].se.fi);
	}

	for(int a = 0; a < q; ++a){
		cout << sol[a] << '\n';
	}

	return 0;
}