#include <bits/stdc++.h>
using namespace std;

#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#define gc getchar
namespace fastio{
	template <typename T> void sca(T &angka){
		T kali = 1; angka = 0; char input = gc();
		while (input < '0' || input > '9'){if (input == '-') kali = -1; input = gc();}
		while(input >= '0' && input <= '9')angka = (angka << 3) + (angka << 1) + input - 48, input = gc();
		angka *= kali;
	}
	template < typename FIRST, typename... REST > void scan( FIRST& first, REST&... rest ); // utama
	void scan() {}
  	template < typename FIRST, typename... REST > void scan( FIRST& first, REST&... rest ){sca(first);scan(rest...);}
}using namespace fastio;

typedef long long ll;
#define fi first
#define se second

#include <ext/pb_ds/assoc_container.hpp>
using namespace __gnu_pbds;

mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());

const int RANDOM = rng();
struct chash{
	const int operator() (int x) const {return x ^ RANDOM;}
};

const int maxn = 1e5 + 1;

int arr[maxn]; ll dp[maxn][2];

gp_hash_table <ll, ll, chash> gp;

int lq = 1, rq = 0; ll val = 0;
inline ll cost(int a, int b){
	while(rq < b){
		ll tmp = gp[arr[rq + 1]];
		gp[arr[rq + 1]]++;
		val += tmp;
		rq++;
	}

	while(lq > a){
		ll tmp = gp[arr[lq - 1]];
		gp[arr[lq - 1]]++;
		val += tmp;
		lq--;
	}

	while(rq > b){
		gp[arr[rq]]--;
		ll tmp = gp[arr[rq]];
		val -= tmp;
		rq--;
	}

	while(lq < a){
		gp[arr[lq]]--;
		ll tmp = gp[arr[lq]];
		val -= tmp;
		lq++;
	}
	return val;
}

void solve(int l, int r, int p, int b, int opl, int opr){
	if(l > r) return;
	int m = (l + r)/2;
	pair <ll, ll> best = make_pair(LLONG_MAX, -1ll);
	// cout << "RANGE " << m << " " << opl << " " << opr << '\n';
	for(ll a = opl; a <= min(m - 1, opr); ++a){
		// cout << "RANGE " << a + 1 << " " << m << " " << dp[a][b] << " " << val << " " << m << '\n';
		// cout << dp[a][b] + val << '\n';
		best = min(best, make_pair(dp[a][b] + cost(a + 1, m), a));
	}
	dp[m][p] = best.fi;
	// cout << "BEST " << m << " " << best.fi << " " << best.se << '\n';
	solve(l, m - 1, p, b, opl, best.se);
	solve(m + 1, r, p, b, best.se, opr);
}

int main(){
	ios_base::sync_with_stdio(0);
	// cin.tie(0);

	int n, k;
	scan(n, k);
	for(int a = 1; a <= n; ++a){
		scan(arr[a]);
	}

	// bikin basecase

	for(int a = 1; a <= n; ++a) dp[a][1] = cost(1, a);

	// for(int a = 1 ; a <= n; ++a) cout << dp[a][1] << " ";
	// cout << '\n';

	// cout << '\n';

	for(int a = 2; a <= k; ++a){
		// cout << "K = " << a << '\n';
		solve(a, n, (a % 2), (a + 1) % 2, a - 1, n);
		// for(int b = 1; b <= n; ++b){
		// 	cout << dp[b][a % 2] << " ";
		// }
		// cout << '\n';
	}

	printf("%lld\n", dp[n][k % 2]);
	// for(int a = 1; a <= n; ++a) cout << arr[a] << " ";
	// cout << '\n';

	return 0;
}