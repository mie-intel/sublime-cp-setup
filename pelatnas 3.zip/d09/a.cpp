#include <bits/stdc++.h>
using namespace std;

#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#define gc getchar
namespace fastio{
	template <typename T> void sca(T &angka){
		T kali = 1; angka = 0; char input = gc();
		while (input < '0' || input > '9'){if (input == '-') kali = -1; input = gc();}
		while(input >= '0' && input <= '9')angka = (angka << 3) + (angka << 1) + input - 48, input = gc();
		angka *= kali;
	}
	template < typename FIRST, typename... REST > void scan( FIRST& first, REST&... rest ); // utama
	void scan() {}
  	template < typename FIRST, typename... REST > void scan( FIRST& first, REST&... rest ){sca(first);scan(rest...);}
}using namespace fastio;

typedef long long ll;
#define fi first
#define se second

const int maxn = 1e3 + 5;
vector <vector <int>> v(maxn);

int hv[maxn], par[maxn], top[maxn], sz[maxn], dep[maxn], st[maxn], en[maxn];
pair <ll, ll> seg[4 * maxn]; ll lz[4 * maxn];
vector <int> euler;
int ez;
int tt = 0;
bitset <maxn> used;

void init(int a, int pr, int dp){
	dep[a] = dp;
	sz[a] = 1;
	hv[a] = -1;
	par[a] = pr;
	int mx = -1;
	for(auto p : v[a]){
		if(p == pr) continue;
		init(p, a, dp + 1);
		if(sz[p] > mx){
			mx = sz[p];
			hv[a] = p;
		}
		sz[a] += sz[p];
	}
}

void decompose(int a, int pr, int tp){
	top[a] = tp;
	euler.push_back(a);
	st[a] = en[a] = tt++;

	if(hv[a] != -1) decompose(hv[a], a, tp), en[a] = en[hv[a]];

	for(auto p : v[a]){
		if(p == pr || p == hv[a]) continue;
		decompose(p, a, p);
		en[a] = en[p];
	}
}

void prop(int l, int r, int v){
	seg[v].fi += lz[v];
	if(l < r){
		lz[2 * v] += lz[v];
		lz[2 * v + 1] += lz[v];
	}
	lz[v] = 0;
}

void build(int l, int r, int v){
	if(l == r){
		seg[v] = make_pair(0, euler[l]);
	}
	else{
		int m = (l + r)/2;
		build(l, m, 2 * v);
		build(m + 1, r, 2 * v + 1);
		seg[v] = max(seg[2 * v], seg[2 * v + 1]);
	}
}

pair <int, int> merge(pair <int, int>  a, pair <int, int>  b){
	return max(a, b);
}

void update(int l, int r, int v, int lq, int rq, int val){
	if(lz[v]) prop(l, r, v);
	if(lq > rq) return;
	if(lq <= l && r <= rq) lz[v] += val;
	if(lz[v]) prop(l, r, v);
	if(l > rq || r < lq || (lq <= l && r <= rq)) return;
	int m = (l + r)/2;
	update(l, m, 2 * v, lq, rq, val);
	update(m + 1, r, 2 * v + 1, lq, rq, val);
	seg[v] = merge(seg[2 * v], seg[2 * v + 1]);
}

pair <int, int> query(int l, int r, int v, int lq, int rq){
	if(lz[v]) prop(l, r, v);
	if(lq > rq) return make_pair(-1, 0);
	// cout << "RANGE " << l << " " << r << " " << v << " " << lq << " " << rq << '\n';
	if(lq <= l && r <= rq) return seg[v];
	if(l > rq || r < lq) return make_pair(-1, 0);
	int m = (l + r)/2;
	if(rq <= m) return query(l, m, 2 * v, lq, rq);
	else if(lq > m + 1) return query(m + 1, r, 2 * v + 1, lq, rq);
	return merge(query(l, m, 2 * v, lq, rq), query(m + 1, r, 2 * v + 1, lq, rq));
}

void upd2(int l, int r, int v, int pos){
	if(l == r){
		used[euler[l]] = 1;
		seg[v] = make_pair(INT_MAX, euler[l]);
	}
	else{
		int m = (l + r)/2;
		if(pos <= m) upd2(l, m, 2 * v, pos);
		else upd2(m + 1, r, 2 * v + 1, pos);
		seg[v] = merge(seg[2 * v], seg[2 * v + 1]);
	}
}

void upd(int a, int b, int val){
	a = euler[a];
	b = euler[b];
	while(top[a] != top[b]){
		if(dep[top[a]] > dep[top[b]]) swap(a, b);
		update(0, ez, 1, st[top[b]], st[b], val);
		b = par[top[b]];
	}

	if(dep[a] > dep[b]) swap(a, b);
	update(0, ez, 1, st[a], st[b], val);	
}

pair <int, int> qu(int a, int b){
	a = euler[a];
	b = euler[b];
	// cout << "EUEU " << a << " " << b << endl;
	pair <int, int> mx = make_pair(-1, 0);
	// cout << "TP " << top[a] << " " << top[b] << endl;
	while(top[a] != top[b]){
		if(dep[top[a]] > dep[top[b]]) swap(a, b);
		// cout << "MX " << mx.fi << " " << mx.se << endl;
		mx = max(mx, query(0, ez, 1, st[top[b]], st[b]));
		b = par[top[b]];
	}

	// cout << st[a] << " " << st[b] << endl;
	if(dep[a] > dep[b]) swap(a, b);
	mx = max(mx, query(0, ez, 1, st[a], st[b]));
	return mx;
}

bool parent(int i, int j){
	int eni = en[euler[i]];
	// if(i <= j && j <= eni){
	// 	cout << euler[i] << " IS PARENT OF " << euler[j] << '\n';
	// }
	return i <= j && en[euler[j]] <= eni;
}

int lgg[maxn];
int mini(int a, int b){
	return dep[a] < dep[b] ? a : b;
}

int sparse[maxn][21];
void build_sparse(){
	lgg[0] = 0;
	for(int a = 2; a < maxn; ++a){
		lgg[a] = lgg[a / 2] + 1;
	}
	for(int a = 0; a <= ez; ++a) sparse[a][0] = euler[a];
	for(int a = 1; a < 21; ++a){
		for(int b = 0; b + (1 << a) <= ez; ++b){
			sparse[b][a] = mini(sparse[b][a - 1], sparse[b + (1 << (a - 1))][a - 1]);
		}
	}
}

int lca(int a, int b){
	int lg = lgg[b - a + 1];
	return mini(sparse[a][lg], sparse[b - (1 << lg) + 1][lg]);
}

set <pair <int, int>> vertex;
priority_queue <pair <ll, ll>> pq;
vector <int> ver;
int cost[maxn];

void rebuild(int a, int pr){
	if(!used[a])
	for(auto p : vertex){
		if(parent(st[a], p.se) && !parent(st[a], p.fi)){
			cost[a]++;
			continue;
		}
		if(parent(st[a], p.fi) && !parent(st[a], p.se)){
			cost[a]++;
			continue;
		}
		if(p.fi == st[a] || p.se == st[a]){
			cost[a]++;
			continue;
		}
		if(lca(p.fi, p.se) == a) cost[a]++;
	}
	// cout << "VISIT " << a << " " << cost[a] << '\n';
	pq.push(make_pair(cost[a], a));
	for(auto p : v[a]){
		if(p == pr) continue;
		rebuild(p, a);
	}
}

int main(){
	ios_base::sync_with_stdio(0);
	// cin.tie(0);

	int n, q;
	used[0] = 1;
	scan(n);
	for(int a = 1; a < n; ++a){
		int i, j;
		scan(i, j);
		v[i].push_back(j);
		v[j].push_back(i);
	}

	init(1, -1, 0);
	decompose(1, -1, 1);

	ez = euler.size() - 1;

	build_sparse();

	scan(q);
	while(q--){
		int i, j;
		scan(i, j);
		if(st[i] > st[j]) swap(i, j);
		// cout << "SIP " << endl;
		vertex.emplace(st[i], st[j]);
	}

	while(!vertex.empty()){
		memset(cost, 0, sizeof cost);
		while(!pq.empty()) pq.pop();
		rebuild(1, -1);
		// for(int a = 1; a <= n; ++a) cout << cost[a] << " \n"[a == n];
		int i = pq.top().se;
		used[i] = 1;
		ver.push_back(i);
		pq.pop();
		vector <pair <int, int>> del;
		for(auto p : vertex){
			if(parent(st[i], p.fi) && !parent(st[i], p.se)){
				del.push_back(p);
				continue;
			}
			if(parent(st[i], p.se) && !parent(st[i], p.fi)){
				del.push_back(p);
				continue;
			}
			if(p.fi == st[i] || p.se == st[i]){
				del.push_back(p);
				continue;
			}
			if(lca(p.fi, p.se) == i) del.push_back(p);
		}
		for(auto p : del) vertex.erase(p);
	}

	cout << ver.size() << '\n';
	for(auto p : ver){
		cout << p << " ";
	}
	cout << '\n';

	return 0;
}

/*
6		                         
2 1
2 3
5 2
4 3
5 6
5
6 6
1 2
1 4
1 4
3 4
*/