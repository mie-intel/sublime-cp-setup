#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	int n, m;
	cin >> n >> m;
	int i, j, k, ci = 0, cj = 0, ck = 0;
	cin >> i >> j >> k;

	string s[2 * n + 1];
	for(int a = 1; a <= 2 * n; ++a){
		s[a] = "~";
		for(int b = 1; b <= 2 * m; ++b) s[a] += '.';
	}

	int it = i;
	int pos_i = -1, pos_j = -1;
	for(int a = 1; a <= 2 * n && it; a += 2){
		for(int b = 1; b <= 2 * m && it; b += 2){
			s[a][b] = s[a + 1][b] = s[a][b + 1] = s[a + 1][b + 1] = '#';
			it--;
			if(it == 0) pos_i = a, pos_j = b;
			ci++;
		}
	}

	if(pos_i == -1 && pos_j == -1){
		pos_i = pos_j = 1;
	}
	else{
	pos_j += 2;
		if(pos_j > 2 * m){
			pos_i += 2;
			pos_j = 1;
		}
	}

	it = k;
	// isi di posisi pos_i
	int cc = 1;
	for(int a = pos_j; a <= 2 * m; a += 2){
		if(cc){
			/*
				x/
				/.
			*/
			s[pos_i][a] = '#';
			s[pos_i][a + 1] = '/';
			s[pos_i + 1][a] = '/';
			s[pos_i + 1][a + 1] = '.';
		}
		else{
			/*
				\x
				.\
			*/
			s[pos_i][a] = '\\';
			s[pos_i][a + 1] = '#';
			s[pos_i + 1][a] = '.';
			s[pos_i + 1][a + 1] = '\\';
		}
		cc = 1 - cc;
		it--;
		ck++;
	}
	pos_i += 2;
	pos_j -= 2;
	cc = 1;
	if(it){
		for(int a = pos_j; a >= 0; a -= 2){
			if(cc){
				/*
					x/
					/.
				*/
				s[pos_i][a] = '#';
				s[pos_i][a + 1] = '/';
				s[pos_i + 1][a] = '/';
				s[pos_i + 1][a + 1] = '.';
			}
			else{
				/*
					\x
					.\
				*/
				s[pos_i][a] = '\\';
				s[pos_i][a + 1] = '#';
				s[pos_i + 1][a] = '.';
				s[pos_i + 1][a + 1] = '\\';
			}
			cc = 1 - cc;
			it--;
			ck++;
		}
	}

	cj = n * m - ci - ck;
	// if(ci != i || cj != j || ck != k){
	// 	cout << "ANJAY\n";
	// 	return 0;
	// }


	for(int a = 1; a <= 2 * n; ++a){
		for(int b = 1; b <= 2 * m; ++b) cout << s[a][b];
		cout << '\n';
	}

	return 0;
}