#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

#include <ext/pb_ds/assoc_container.hpp>
using namespace __gnu_pbds;

typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> iset;

const ll RANDOM = chrono::steady_clock::now().time_since_epoch().count();

struct chash{
	const ll operator()(ll x){return x ^ RANDOM;}
};

int main(){
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	

	return 0;
}