#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

// #include <ext/pb_ds/assoc_container.hpp>
// using namespace __gnu_pbds;

// typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> iset;

// const ll RANDOM = chrono::steady_clock::now().time_since_epoch().count();

// struct chash{
//     const ll operator()(ll x){return x ^ RANDOM;}
// };

const int maxn = 1e5 + 2;
vector <vector <pair <ll, ll>>> v(maxn);

vector <int> euler;
int st[maxn], en[maxn], dep[maxn];
ll dis[maxn], bawah[maxn];
bitset <maxn> vis = 0;

int tt = 0;
void dfs(int a, int pr, int dp){
    euler.push_back(a);
    dep[a] = dp;
    st[a] = en[a] = tt++;
    for(auto [p, w] : v[a]){
        if(p == pr) continue;
        dis[p] = dis[a] + w;
        dfs(p, a, dp + 1);
        euler.push_back(a);
        en[a] = tt++;
    }
}

const int maxk = 21;
int sparse[maxn + maxn][maxk];
int lgg[maxn + maxn];

int mini(int a, int b){
    return dep[a] < dep[b] ? a : b;
}

void build_sparse(){
    for(int a = 2; a < maxn + maxn; ++a){
        lgg[a] = lgg[a / 2] + 1;
    }

    for(int a = 0; a < euler.size(); ++a) sparse[a][0] = euler[a];
    for(int b = 1; b < maxk; ++b){
        for(int a = 0; a + (1 << b) < euler.size(); ++a){
            sparse[a][b] = mini(sparse[a][b - 1], sparse[a + (1 << (b - 1))][b - 1]);
        }
    }
}

int lca(int a, int b){
    if(st[a] > st[b]) swap(a, b);
    int lg = lgg[st[b] - st[a] + 1];
    return mini(sparse[st[a]][lg], sparse[st[b] - (1 << lg) + 1][lg]);
}

vector<long long> answer(int N, int K, int Q, vector<int> p,
                         vector<long long> C, vector<long long> W,
                         vector<int> U, vector<int> V) {

    // cout << "AMAN" << endl;

    // for(int a = 0; a < N - 1; ++a){
    //     cout << a + 1 << " " << p[a] << " " << C[a] << '\n';
    //     cout << endl;
    // }

    for(int a = 0; a < N - 1; ++a){
        int id = a + 1;
        v[id].emplace_back(p[a], C[a]);
        v[p[a]].emplace_back(id, C[a]);
    }

    vector <int> satu;

    ll root = 0;
    vector <pair <ll, pair <ll, ll>>> edges;
    for(int a = 0; a < N; ++a){
        sort(v[a].begin(), v[a].end());
        if(v[a].size() > 1) root = a;
        else{
            satu.emplace_back(a);
        }
    }
    // add laju
    for(int a = 0; a < K; ++a){
        int id = a + 1;
        edges.emplace_back(W[a], make_pair(satu[id - 1], satu[id % K]));
    }

    dfs(root, -1, 0);

    for(int a = 0; a < edges.size(); ++a){
        if(dis[edges[a].se.fi] + edges[a].fi <= dis[edges[a].se.se]){
            v[edges[a].se.fi].emplace_back(edges[a].se.se, edges[a].fi);
            v[edges[a].se.se].emplace_back(edges[a].se.fi, edges[a].fi);
            // hapus edges[a].se.se
            int i = int(lower_bound(v[root].begin(), v[root].end(), make_pair(edges[a].se.se, -1ll)) - v[root].begin());
            v[root][i].se = 1e17;
            i = int(lower_bound(v[edges[a].se.se].begin(), v[edges[a].se.se].end(), make_pair(root, -1ll)) - v[edges[a].se.se].begin());
            v[edges[a].se.se][i].se = 1e17;
        }
        else if(dis[edges[a].se.se] + edges[a].fi <= dis[edges[a].se.fi]){
            v[edges[a].se.fi].emplace_back(edges[a].se.se, edges[a].fi);
            v[edges[a].se.se].emplace_back(edges[a].se.fi, edges[a].fi);
            int i = int(lower_bound(v[root].begin(), v[root].end(), make_pair(edges[a].se.fi, -1ll)) - v[root].begin());
            v[root][i].se = 1e17;
            i = int(lower_bound(v[edges[a].se.fi].begin(), v[edges[a].se.fi].end(), make_pair(root, -1ll)) - v[edges[a].se.fi].begin());
            v[edges[a].se.fi][i].se = 1e17;
        }
        else{
            continue;
        }
    }

    // for(int a = 0; a < N; ++a){
    //     cout << "A " << a << ": " << bawah[a] << '\n';
    // }

    // memset(bawah, 1, sizeof bawah);
    priority_queue <pair <ll, ll>> pq;

    // for(int a = 0; a < N; ++a){
    //     if(v[a].size() == 1){
    //         bawah[a] = 0;
    //         pq.emplace(bawah[a], a);
    //     }
    // }

    memset(dis, 1, sizeof dis);
    dis[root] = 0;
    pq.emplace(-dis[root], root);
    while(!pq.empty()){
        int i = pq.top().se;
        pq.pop();
        if(vis[i]) continue;
        vis[i] = 1;
        for(auto [p, w] : v[i]){
            if(dis[p] > dis[i] + w){
                dis[p] = dis[i] + w;
                pq.emplace(-dis[p], p);
            }
        }
    }

    for(int a = 0; a < N; ++a){
        cout << dis[a] << " \n"[a == N - 1];
    }

    vector <ll> res;
    for(int a = 0; a < Q; ++a){
        // cout << lc << " " << tp << '\n';
        res.push_back(dis[U[a]] + dis[V[a]]);
    }
    return res;
}