#ifndef __HARVEST_MOON_H__
#define __HARVEST_MOON_H__

#include <vector>
using namespace std;

vector<long long> answer(int N, int K, int Q, vector<int> p,
                         vector<long long> C, vector<long long> W,
                         vector<int> U, vector<int> V);

#endif
