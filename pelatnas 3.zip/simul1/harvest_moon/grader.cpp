#include "harvest_moon.h"
#include <bits/stdc++.h>

using namespace std;

int main() {
  int N, K, Q;
  vector<int> p, u, v;
  vector<long long> c, w;

  cin >> N >> K >> Q;

  p.resize(N - 1);
  c.resize(N - 1);

  for (int i = 0; i < N - 1; ++i) {
    cin >> p[i];
  }
  for (int i = 0; i < N - 1; ++i) {
    cin >> c[i];
  }

  w.resize(K);

  for (int i = 0; i < K; ++i) {
    cin >> w[i];
  }

  u.resize(Q);
  v.resize(Q);
  for (int i = 0; i < Q; ++i) {
    cin >> u[i];
  }
  for (int i = 0; i < Q; ++i) {
    cin >> v[i];
  }

  vector<long long> ans = answer(N, K, Q, p, c, w, u, v);
  assert((int)ans.size() == Q);

  for (int i = 0; i < Q; ++i) {
    if (i != 0)
      cout << " ";
    cout << ans[i];
  }
  cout << endl;

  return 0;
}