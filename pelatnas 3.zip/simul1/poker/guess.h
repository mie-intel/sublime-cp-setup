#ifndef __GUESS_H__
#define __GUESS_H__

#include <vector>
using namespace std;

int guess(vector<vector<pair<int, int>>> marked_card);

#endif
