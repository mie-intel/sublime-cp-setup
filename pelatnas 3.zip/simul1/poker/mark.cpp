#include "mark.h"

#include <bits/stdc++.h>
using namespace std;
vector <vector <pair <int, int>>> bit;

#define fi first
#define se second

void build(){
    bit = {
        {{0, 0}, {1, 1}},
        {{0, 0}, {2, 1}},
        {{0, 0}, {1, 2}},

        // dari {0, 1} ke 6 arah
        {{0, 1}, {0, 2}},
        {{0, 1}, {1, 2}},
        {{0, 1}, {1, 1}},
        {{0, 1}, {2, 2}},
        {{0, 1}, {2, 0}},
        {{0, 1}, {1, 0}},

        // dari {1, 0} ke 4 arah
        {{1, 0}, {2, 0}},
        {{1, 0}, {2, 1}},
        {{1, 0}, {2, 2}},
        {{1, 0}, {1, 1}},

        // dari {2, 0} ke 3 kanan
        {{0, 2}, {1, 0}},
        {{0, 2}, {1, 1}},
        {{0, 2}, {2, 1}},
        {{1, 2}, {0, 2}}, // khusus ini dibalik

        // dari {1, 1} ke 4 arah
        {{1, 1}, {1, 2}},
        {{1, 1}, {2, 2}},
        {{1, 1}, {2, 1}},
        {{1, 1}, {2, 0}},

        // dari {1, 2} ke 3 arah
        {{1, 2}, {2, 2}},
        {{1, 2}, {2, 1}},
        {{1, 2}, {2, 0}},

        // dari {2, 1} ke 2 arah
        {{2, 1}, {2, 0}},
        {{2, 1}, {2, 2}},

        // penentu
        {{0, 0}, {1, 0}},
        {{0, 0}, {0, 1}}
    };  
}

// returns vector of two pairs that represent number n
vector<vector<pair<int, int>>> mark_card(int n) {
    // first bit
    if(bit.empty()){
        build();
    }
    vector <vector <pair <int, int>>> v;
    for(int a = 0; a < 26; ++a){
        if(n & (1 << a)) v.push_back(bit[a]);
    }
    v.push_back(bit[26]);
    v.push_back(bit[27]);
    // bit ke 10
    return v;
}
