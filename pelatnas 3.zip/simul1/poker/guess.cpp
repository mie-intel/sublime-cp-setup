#include "guess.h"

#include <bits/stdc++.h>
using namespace std;

#define fi first
#define se second

vector <vector <pair <int, int>>> bit2;

void build2(){
    bit2 = {
        {{0, 0}, {1, 1}},
        {{0, 0}, {2, 1}},
        {{0, 0}, {1, 2}},

        // dari {0, 1} ke 6 arah
        {{0, 1}, {0, 2}},
        {{0, 1}, {1, 2}},
        {{0, 1}, {1, 1}},
        {{0, 1}, {2, 2}},
        {{0, 1}, {2, 0}},
        {{0, 1}, {1, 0}},

        // dari {1, 0} ke 4 arah
        {{1, 0}, {2, 0}},
        {{1, 0}, {2, 1}},
        {{1, 0}, {2, 2}},
        {{1, 0}, {1, 1}},

        // dari {2, 0} ke 3 kanan
        {{0, 2}, {1, 0}},
        {{0, 2}, {1, 1}},
        {{0, 2}, {2, 1}},
        {{1, 2}, {0, 2}}, // khusus ini dibalik

        // dari {1, 1} ke 4 arah
        {{1, 1}, {1, 2}},
        {{1, 1}, {2, 2}},
        {{1, 1}, {2, 1}},
        {{1, 1}, {2, 0}},

        // dari {1, 2} ke 3 arah
        {{1, 2}, {2, 2}},
        {{1, 2}, {2, 1}},
        {{1, 2}, {2, 0}},

        // dari {2, 1} ke 2 arah
        {{2, 1}, {2, 0}},
        {{2, 1}, {2, 2}},

        // penentu
        {{0, 0}, {1, 0}},
        {{0, 0}, {0, 1}}
    };  
}

bool check(vector<vector<pair<int, int>>> v){
    bool ada = 0, ada2 = 0;
    for(int a = 0; a < v.size(); ++a){
        if(v[a] == bit2[26]) ada = 1;
        if(v[a] == bit2[27]) ada2 = 1;
    }
    return (ada && ada2);
}

void rotate(vector<vector<pair<int, int>>> &marked_card){
    for(int a = 0; a < marked_card.size(); ++a){
        for(int b = 0; b <= 1; ++b){
            if(marked_card[a][b] == make_pair(1, 0)){
                marked_card[a][b] = make_pair(0, 1);
            }
            else if(marked_card[a][b] == make_pair(0, 1)){
                marked_card[a][b] = make_pair(1, 2);
            }
            else if(marked_card[a][b] == make_pair(1, 2)){
                marked_card[a][b] = make_pair(2, 1);
            }
            else if(marked_card[a][b] == make_pair(2, 1)){
                marked_card[a][b] = make_pair(1, 0);
            }
            else if(marked_card[a][b] == make_pair(0, 0)){
                marked_card[a][b] = make_pair(0, 2);
            }
            else if(marked_card[a][b] == make_pair(0, 2)){
                marked_card[a][b] = make_pair(2, 2);
            }
            else if(marked_card[a][b] == make_pair(2, 2)){
                marked_card[a][b] = make_pair(2, 0);
            }
            else if(marked_card[a][b] == make_pair(2, 0)){
                marked_card[a][b] = make_pair(0, 0);
            }
        }
    }
}

// returns an integer represented by vector of two pairs (possibly rotated)
int guess(vector<vector<pair<int, int>>> marked_card) {
    int ans = 0;
    if(bit2.empty()){
        build2();
    }

    while(!check(marked_card)){
        rotate(marked_card);
    }

    for(int a = 0; a < marked_card.size(); ++a){
        for(int b = 0; b < 26; ++b){
            if(marked_card[a] == bit2[b]){
                ans |= (1 << b);
            }
        }        
    }

    // cout << '\n';
    // for(int a = 0; a < marked_card.size(); ++a){
    //     cout << "{" << marked_card[a][0].fi << " " << marked_card[a][0].se << " : " << marked_card[a][1].fi << " " << marked_card[a][1].se << "}\n";
    // }

    // cout << "ANS " << ans << '\n';

  return ans;
}
