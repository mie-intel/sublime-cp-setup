#include "guess.h"
#include "mark.h"

#include <bits/stdc++.h>
using namespace std;

vector<vector<pair<int, int>>>
rotate(vector<vector<pair<int, int>>> marked_card, int times) {
  vector<vector<pair<int, int>>> ret;

  for (vector<pair<int, int>> &scratch : marked_card) {
    for (int k = 0; k < times; ++k) {
      pair<int, int> new_scratch;

      scratch[0].first -= 1;
      scratch[0].second -= 1;
      new_scratch.first = (scratch[0].second) + 1;
      new_scratch.second = (-scratch[0].first) + 1;
      scratch[0] = new_scratch;

      scratch[1].first -= 1;
      scratch[1].second -= 1;
      new_scratch.first = (scratch[1].second) + 1;
      new_scratch.second = (-scratch[1].first) + 1;
      scratch[1] = new_scratch;
    }

    ret.push_back(scratch);
  }

  return ret;
}

bool validate(vector<vector<pair<int, int>>> marked_card) {
  map<vector<pair<int, int>>, bool> scratched;

  for (vector<pair<int, int>> &scratch : marked_card) {
    if (scratch.size() != 2)
      return false;

    if (__gcd(abs(scratch[0].first - scratch[1].first),
              abs(scratch[0].second - scratch[1].second)) != 1)
      return false;

    if (scratched[scratch])
      return false;
    swap(scratch[0], scratch[1]);
    if (scratched[scratch])
      return false;

    scratched[scratch] = true;
    swap(scratch[0], scratch[1]);
    scratched[scratch] = true;
  }

  return true;
}

int main() {
  int Q;
  bool canRotate;

  cin >> Q >> canRotate;

  vector<int> cards(Q), order(Q), ans(Q);
  vector<vector<vector<pair<int, int>>>> marked_cards(Q);

  for (int i = 0; i < Q; ++i) {
    cin >> cards[i];
  }

  for (int i = 0; i < Q; ++i) {
    marked_cards[i] = mark_card(cards[i]);

    if (!validate(marked_cards[i])) {
      cout << "Marks on the card are not valid!" << endl;
      exit(0);
    }

    order[i] = i;
  }

  srand(69); // seed pada grader juri belum tentu sama
  random_shuffle(order.begin(), order.end());
  for (int i = 0; i < Q; ++i) {
    random_shuffle(marked_cards[order[i]].begin(),
                   marked_cards[order[i]].end());

    if (canRotate) {
      ans[order[i]] = guess(rotate(marked_cards[order[i]], (int)rand() % 4));
    } else {
      ans[order[i]] = guess(marked_cards[order[i]]);
    }
  }

  for (int i = 0; i < Q; ++i) {
    cout << ans[i] << endl;
  }

  return 0;
}