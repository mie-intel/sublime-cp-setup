#ifndef __MARK_H__
#define __MARK_H__

#include <vector>
using namespace std;

vector<vector<pair<int, int>>> mark_card(int N);

#endif
