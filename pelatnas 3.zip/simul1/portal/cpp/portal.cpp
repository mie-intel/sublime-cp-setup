#include "portal.h"
#include <vector>

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define fi first
#define se second

set <pair <ll, ll>> st;
int aman = 0;
vector <int> u;

void init(int N, vector<long long> v) {
	sort(v.begin(), v.end());
	u = v;
	st.emplace(0, 0);
	int last = 0;
	sort(v.begin(), v.end());
	for(int a = 0; a < N; ++a){
		if(v[a] > last + 1) break;
		last = prev(st.end())->fi + v[a];
		st.emplace(last, v[a]);
	}
}

bool query(long long k, long long a, long long b) {
	auto p = st.lower_bound(make_pair(a, -1));
	if(p == st.end()) return false;
	return p->se <= u[k];
}