#include "portal.h"
#include <stdio.h>
#include <vector>

int main() {
  int N, Q;
  scanf("%d %d", &N, &Q);

  std::vector<long long> P(N);
  for (int i = 0; i < N; i++)
    scanf("%lld", &P[i]);

  init(N, P);

  for (int i = 0; i < Q; i++) {
    long long k, a, b;
    scanf("%lld %lld %lld", &k, &a, &b);
    if (query(k, a, b))
      printf("Yes\n");
    else
      printf("No\n");
  }

  return 0;
}