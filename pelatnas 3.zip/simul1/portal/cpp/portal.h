#ifndef __PORTAL_H__
#define __PORTAL_H__

#include <vector>

void init(int N, std::vector<long long> P);

bool query(long long k, long long a, long long b);

#endif