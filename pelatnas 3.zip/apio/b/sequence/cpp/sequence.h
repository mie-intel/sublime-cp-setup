#include <vector>

int sequence(int N, std::vector<int> A);
