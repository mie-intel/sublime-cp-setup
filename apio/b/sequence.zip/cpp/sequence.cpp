#include "sequence.h"

#include <vector>

int sequence(int N, std::vector<int> A) {
  return 0;
}
